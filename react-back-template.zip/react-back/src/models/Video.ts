export default interface Video {
    id?: number;
    title: string;
    description?: string;
    url: string;
    
    //repelerAgua(): void;
  }